function getLocation(){
    if(window.navigator.geolocation){
        window.navigator.geolocation.getCurrentPosition(showPosition,errorDisplay); //passing function as a parameter
    }
}

function showPosition(position){
    document.getElementById("demo").innerHTML="Latitude: "+position.coords.latitude+
    "<br/>Longitude: "+position.coords.longitude
}

function errorDisplay(err){
    var d=document.getElementById("demo");
    console.log("error code: "+err.code)
    switch(err.code){
        case err.PERMISSION_DENIED:  //error code:1
        d.innerHTML="User Denied";
        break;
        case err.POSITION_UNAVAILABLE:
        d.innerHTML="POSITION_UNAVAILABLE";
        break;
        case err.TIMEOUT:
        d.innerHTML="Timeout";
        break;
        case err.UNKNOWN_ERROR:
        d.innerHTML="Unknown Error";
        break;
    }

}